# 🦇 NCI SCANNER v3.5  
Advanced Web Recon Engine  

---

## 🚀 Getting Started

### 1️⃣ Create Account & Activate Trial

- Use **@nci_manager_bot** to create a new user account.
- After registration, activate the **1-day trial subscription**.
- Once the trial is active, you can access and use the tool.

---

## 📂 Importing Local Files

To import your local data:

| Slot | What it controls |
|---|---|
| `indikey` | Keywords that identify a shell |
| `pathkey` | Keywords that identify a shell |
| `indi` | Directory paths /admin/ |
| `path` | File paths `/c99.php` |
| `404` | FORCE WAF BYPASS |


### Two Accepted File Formats

**JSON array** (works in both `.json` and `.txt`):
```json
["/shell.php","/c99.php","/r57.php"]
```

**Plain text** (`.txt` only, one entry per line):
```
/shell.php
/c99.php
#this hash is a NORMAL keyword, not a comment
<---#nci#---> this whole line is skipped
/index.php<---#nci#--->this part is stripped, /index.php kept
```


1. Locate the compressed `data` archive.
2. Unzip the archive into the **same directory** as the main tool executable.  
*Your folder structure should look like this:*
```text
nci_scanner.exe
/data
data/404.txt
data/path.json
```
3. Open the `/data` folder.  
4. Make sure all TXT (`.txt`) and JSON (`.json`) files are in the correct format and located inside the `/data` folder (e.g., `data/404.txt`, `data/404.json`).  
5. Add or update any custom TXT or JSON files in the `/data` directory.  
The tool will automatically detect and process all TXT and JSON files inside `/data`.
---

### When to Use Local Files

**Use when:**
- You have a custom configuration list
- You want Scan by Your Private files
- Testing your private signatures before update

**Don't use when:**
- Running on a machine without the `data/` folder — tool will be run without any issue, no setup needed

---

### What to Avoid

- **Partial JSON** — if a `.json` file has even one quote/bracket error, the whole file is skipped. Use `.txt` plain text if you're editing manually.
- **Wrong folder location** — `data/` must be next to the binary, not inside src. If the tool is run from a different working directory, the path won't resolve.
- **Empty files** — a zero-byte file is silently skipped. The slot falls through to the next option.

## 🛡 Disclaimer

For authorized security testing and research purposes only.  
Unauthorized usage is strictly prohibited.

---

NCI SCANNER v3.5  
Nuclear Crime Investigation Corps — Cyber Intelligence Unit © 2026